const constants = {
  login_success: "Login Successfully!",
  register_success: "You are registed successfully, you will go to the community dashboard!",
  register_error_email: "This email is registed already!",
  register_error: "You are not registed, try again!",
  permisson_error: "You are not allowed to post, because you are not a member of levelshealth.com.",
  post_alert: "Please fill the subject and body",
  channel_alert: "Please fill the channel name"
}

export default constants 