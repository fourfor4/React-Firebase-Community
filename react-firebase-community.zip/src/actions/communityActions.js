export const SET_CHANNEL_ID = 'SET_CHANNEL_ID'

export const setChannelId = (payload) => {
  return {
    type: SET_CHANNEL_ID,
    payload: payload
  }
}